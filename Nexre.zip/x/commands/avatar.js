const { Client, SlashCommandBuilder, Partials, GatewayIntentBits, StringSelectMenuBuilder, PermissionFlagsBits, ButtonBuilder, ActionRowBuilder, ButtonStyle, Events, EmbedBuilder} = require('discord.js');
const axios = require('axios');
const ms = require("ms")
const db = require("croxydb")
const os = require(`os`)
const Discord = require("discord.js");
const INTENTS = Object.entries(Discord.IntentsBitField.Flags).filter(([K]) => ![].includes(K)).reduce((t, [, V]) => t | V, 0);
const client = new Discord.Client({ intents: INTENTS });
const moment = require('moment');
require("moment-duration-format");

module.exports = class Istatistik {
    constructor() {
    this.name = 'avatar';
    this.slashCommand = new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Avatarına Bakarsın | Avatlara Bakarsın')
    .addUserOption(option =>
        option
          .setName('kullanici')
          .setDescription('Bilgilerini almak istediğiniz kullanıcıyı seçin.')
          .setRequired(false)
        )
    .toJSON();
  }

async run(interaction) {
let member = interaction.user
const owner = interaction.guild.members.cache.get(interaction.guild.ownerId);
    
const userOption = interaction.options.getUser('kullanici');
    
const targetUser = userOption ? userOption : interaction.user;

const embed = new EmbedBuilder()
.setColor("Blue")
.setAuthor({ name: `${targetUser.username} adlı kullanıcının avatarı:` })
.setDescription(`${targetUser} adlı kullanıcının avatarı:`)
.setFooter({ text: `Nexre © 2023` })
.setImage(targetUser.displayAvatarURL({dynamic:true})) 
.setTimestamp()
interaction.reply({ embeds: [embed] })

    }
};