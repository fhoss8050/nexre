const { Client, SlashCommandBuilder, Partials, GatewayIntentBits, StringSelectMenuBuilder, PermissionFlagsBits, ButtonBuilder, ActionRowBuilder, ButtonStyle, Events, EmbedBuilder} = require('discord.js');
const axios = require('axios');
const ms = require("ms")
const db = require("croxydb")
const os = require(`os`)
const Discord = require("discord.js");
const INTENTS = Object.entries(Discord.IntentsBitField.Flags).filter(([K]) => ![].includes(K)).reduce((t, [, V]) => t | V, 0);
const client = new Discord.Client({ intents: INTENTS });
const moment = require('moment');
require("moment-duration-format");

module.exports = class Istatistik {
    constructor() {
    this.name = 'arrow';
    this.slashCommand = new SlashCommandBuilder()
    .setName('arrow')
    .setDescription('Bota Logonu Yaptırırsın')
    .addStringOption(option =>
      option
      .setName('yazi')
      .setDescription('Bilgilerini almak istediğiniz kullanıcıyı seçin.')
      .setRequired(true)
  )
    .toJSON();
  }

async run(interaction) {
const textOption = interaction.options.getString('yazi');
let api = `https://dynamic.brandcrowd.com/asset/logo/1a2ebc7a-1b24-466a-bee7-9a0e8f5d8395/logo?v=4&text=${textOption}`
  
interaction.reply(`${api}`)
    }
};