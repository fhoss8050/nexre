module.exports = {

    token2: 'MTExOTkwOTMzNjY5NzgxNTExMA.Gya5ar.eEiCt5ua07ug23a7Rt7Woeej06amV6YfYXTk_c', //SHARD İÇİN
    botdurum: 'Developed By Valoue',
    botlink: 'https://discord.com/api/oauth2/authorize?client_id=1120030176592539710&permissions=8&scope=bot%20applications.commands',
    botid: '1120030176592539710',
    botdestek: 'https://discord.gg/xnmCwcRhTE',
    status: '1126954793454284894'

}