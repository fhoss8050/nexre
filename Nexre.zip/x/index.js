const { EmbedBuilder, GatewayIntentBits, ButtonStyle } = require("discord.js");
const { ActionRowBuilder, ButtonBuilder, MessageAttachment, ActivityType, TextInputBuilder, ModalBuilder,  } = require("discord.js");
const { CommandHandler } = require('djs-commands');
const { Collection } = require("discord.js");
const { Client, SlashCommandBuilder, Partials, StringSelectMenuBuilder, PermissionFlagsBits, Events } = require('discord.js');
const axios = require('axios');
const ms = require("ms")
const db = require("croxydb")
const os = require(`os`)
const moment = require('moment');
require("moment-duration-format");
const Discord = require("discord.js");
const INTENTS = Object.entries(Discord.IntentsBitField.Flags).filter(([K]) => ![].includes(K)).reduce((t, [, V]) => t | V, 0);
const client = new Discord.Client({ intents: INTENTS });
const token = require('./panel/config.js');
const config = require('./panel/config.js');

const CH = new CommandHandler({
	folder: __dirname + '/commands/',
	globalCommandRefresh: true, //not including this or setting as false reverts to not updating commands.
});
client.on('interactionCreate', async (interaction) => {
	if (!interaction.isChatInputCommand()) return;
	let cmd = CH.getCommand(interaction.commandName);
	if (!cmd) return;
	try {
		cmd.run(interaction);
	} catch (e) {
		console.log(e);
	}
});

client.on("ready", () => {
	console.log(`[READY] ${client.user.tag} Bot Başarıyla Aktif Oldu`)
    const activities = [
      `Vilron Bot`,
      `Guard, Sayaç, Kayıt Ve Daha Fazlası!`,
      `Tüm Sistemli Komutlarıyla Sizlerle!`,
      `Eee Daha Ne Duruyorsun Sunucuna Eklesene.`
    ]
    let i = 0;
    setInterval(() => {
      client.user.setActivity({
        name: activities[i++ % activities.length],
        type: ActivityType.Streaming,
        url: "https://www.twitch.tv/"
      });
    }, 5000)
  });

client.on("ready", () => {
require("./panel/config.js")
require("./panel/openai.js")
console.log('[PANEL] Bütün Sistemler Başarıyla Aktif!')
});

client.login(process.env.token).catch(e => {
console.log("[ERROR] İtents'ler Kapalı Durumda! Bot Düştü.")
})

client.login(process.env.token)

let startTime;

client.once('ready', () => {
    console.log('Bot is ready');
    startTime = Date.now();
});

client.on('messageCreate', (message) => {
    if (message.content === '!çalışma-süresi') {

      const YetkiYok = new EmbedBuilder()
      .setDescription(`Bu komutu birtek <@1107093737814900838> kullanabilir`)
      .setColor('Red')
    if(message.author.id !== "1107093737814900838"){
    return message.reply({embeds: [YetkiYok]})
    }

        const currentTime = Date.now();
        const uptime = currentTime - startTime;

        const uptimeInSeconds = Math.floor(uptime / 1000);
        const uptimeInMinutes = Math.floor(uptimeInSeconds / 60);
        const uptimeInHours = Math.floor(uptimeInMinutes / 60);

        message.channel.send(`Bot çalışma süresi: ${uptimeInHours} saat, ${uptimeInMinutes % 60} dakika, ${uptimeInSeconds % 60} saniye.`);
    }
});

client.on('messageCreate', (message) => {
  if (message.content === '!kapat') {
    const YetkiYok = new EmbedBuilder()
    .setDescription(`Bu komutu birtek <@1107093737814900838> kullanabilir`)
    .setColor('Red')
  if(message.author.id !== "1107093737814900838"){
  return message.reply({embeds: [YetkiYok]})
  }
  
    const uyarılar = [
      "Ben Kaçıyorum Herkese BayBay ♿",
      "Yemek Yemeye Gidiyorum... 🍌",
      "Yılanla Boğuşmaya Gidiyorum! 🐍",
      "Film İzlemeye Gidiyorum 🎭",
    ];
    let uyarımesaj = uyarılar[Math.floor(Math.random() * uyarılar.length)];
    let csl = `${config.status}`
    client.channels.cache.get(csl).send('Bot kapanıyor...').then(() => {
    message.channel.send({ embeds: [
    new EmbedBuilder()
    .setTitle('Kapanıyorum...')
    .setDescription(`${uyarımesaj}`)
    .setFooter({ text: `Botun Kapanma Tarihi` })
    .setTimestamp()
    ]})
    process.exit();
    });
  }
});